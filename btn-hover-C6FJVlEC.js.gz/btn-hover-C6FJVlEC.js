import{a as e}from"./script-DRXdFrYZ.js";function t(){if(e)return;document.querySelectorAll(".btn-hover").forEach(e=>{const t=e.querySelector(".btn");t&&(e.addEventListener("mouseenter",()=>{t.classList.add("hover")}),e.addEventListener("mouseleave",()=>{t.classList.remove("hover")}))})}export{t as default};
//# sourceMappingURL=btn-hover-C6FJVlEC.js.map
